package com.java;

public class OverlaodingTypePromotion {
	void add(int a, int b) {
		System.out.print(a+b);
	}


		void add(long a, long b) {
			System.out.print(a+b);
			
			
	}
		public static void main(String[] args) {
			OverlaodingTypePromotion otp= new OverlaodingTypePromotion();
				otp.add(10,20);
				//otp.add(10,20,40);
			
			
		}

}
