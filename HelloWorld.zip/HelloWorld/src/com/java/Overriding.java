package com.java;

public class Overriding {
	void run() {
		System.out.println("running");
	}
}
class Bike extends Overriding{
	void run() {
		System.out.println("mode on");
	}
	
	public static void main(String[] args) {
		Bike b= new Bike();
		b.run();
		
	}
}

	


		
		
	
	





